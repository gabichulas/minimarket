/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minimarket_1;

/**
 *
 * @author lopez
 */
public class Vendedor {
    //atributos
    private long Cuil=0;
    private String Apellido="";
    private String Nombre="";
    private String Email="";
    private String Telefono="";
    private String Domicilio="";
    //constructor base
    public Vendedor(long cuil, String ape, String nom, String email, String tel, String domi){
        this.Cuil=cuil;
        this.Apellido=ape;
        this.Nombre=nom;
        this.Email=email;
        this.Telefono=tel;
        this.Domicilio=domi;
    }
    public Vendedor(Vendedor vend){
        this.Cuil=vend.Cuil;
        this.Apellido=vend.Apellido;
        this.Nombre=vend.Nombre;
        this.Email=vend.Email;
        this.Telefono=vend.Telefono;
        this.Domicilio=vend.Domicilio;
    }
    public Vendedor(int cuil_1){
        this.Cuil=cuil_1;
    }
    public long getCuil(){
        return this.Cuil;
    }
    public String getApellido(){
        return this.Apellido;      
    }
    public String getNombre(){
        return this.Nombre;       
    }
    public String getEmail(){
        return this.Email;
    }
    public String getTelefono(){
        return this.Telefono;
    }
    public String getDomicilio(){
        return this.Domicilio;
    }
    public Vendedor Vendedor(){
        return this;
    }
}

