/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minimarket_1;

/**
 *
 * @author lopez
 */
public class Factura {
    //atributos
    private int IdFactura=0;
    private int NumFactura=0;
    private String Fecha="";
    private float Total=0;
    private long Cuit=0;
    private long Cuil=0;
    //constructor base
    public Factura(int idfac, int numfac, String fecha, float total, long cuit, long cuil){
        this.IdFactura=idfac;
        this.NumFactura=numfac;
        this.Fecha=fecha;
        this.Total=total;
        this.Cuit=cuit;
        this.Cuil=cuil;               
    }
    //constructor de clonar
    public Factura(Factura fac){
        this.IdFactura=fac.IdFactura;
        this.NumFactura=fac.NumFactura;
        this.Fecha=fac.Fecha;
        this.Total=fac.Total;
        this.Cuit=fac.Cuit;
        this.Cuil=fac.Cuil;
    }
    //constructor clave primaria
    public Factura(int idfactu){
        this.IdFactura=idfactu;
    }
    //getter
    public int getIdFactura(){
        return this.IdFactura;
    }
    public int getNumFactura(){
        return this.NumFactura;
    }
    public String getFecha(){
        return this.Fecha;       
    }
    public float getTotal(){
        return this.Total;
    }
    public long getCuit(){
        return this.Cuit;
    }
    public long getCuil(){
        return this.Cuil;
    }
    public Factura Factura(){
        return this;
    }
}
