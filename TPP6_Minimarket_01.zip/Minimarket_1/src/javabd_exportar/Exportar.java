/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javabd_exportar;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Laura Noussan Lettry <laura@lnoussanl.org>
 * @Name exportar
 * @Created on 16/05/2015
 */
public class Exportar {
    private JOptionPane mensaje;
    private JDialog dialogo;
    private JFileChooser archivo;
    private BufferedWriter salida;
    
    public Exportar(DefaultTableModel modelo, int cantRows, int cantCols){
        //para setear el FileChooser
        archivo= new JFileChooser();
        archivo.setFileSelectionMode(javax.swing.JFileChooser.FILES_AND_DIRECTORIES);
        String mens1="";
        
        try {  
            StringBuilder cadena2=new StringBuilder("");
            int status = archivo.showOpenDialog(null);
            if (status == javax.swing.JFileChooser.APPROVE_OPTION) {
            File arch1= archivo.getSelectedFile();
          
            salida = new BufferedWriter( new FileWriter( arch1 + ".csv" ) );

            for (int i=0; i < cantCols; i++){
                cadena2.append(modelo.getColumnName(i));
                cadena2.append(",");
                    }
                cadena2.append("\n");
            for (int i=0 ; i<cantRows ; i++){
                for(int j=0; j < cantCols; j++){
                    if(modelo.getValueAt(i,j)==null)
                        //por la tabla Notas que puede tener valores nulos para
                        //evitar la excepciń NullPointer
                        cadena2.append("sin datos");
                    else
                        cadena2.append(modelo.getValueAt(i, j).toString());
                    cadena2.append(",");
                }
                cadena2.append("\n");
                salida.write(cadena2.toString());
                cadena2=new StringBuilder("");
            }
            salida.close();

          }
            else if (status == javax.swing.JFileChooser.CANCEL_OPTION) {
              mens1="Ha cancelado el diálogo";
              crearDialogo(mens1,"Información");
            }  

        }
        catch (IOException | NullPointerException ioe) {
             mens1="Error al crear el archivo\nLocalización: "+ioe.getLocalizedMessage();
             crearDialogo(mens1,"Excepción");
           }
        
    }

    private void crearDialogo(String m,String t){
    int tipo=0;
    if (t.equals("Excepción")) tipo =JOptionPane.ERROR_MESSAGE;
    if(t.equals("Excepción SQL")) tipo= JOptionPane.ERROR_MESSAGE;
    if (t.equals("Información")) tipo=JOptionPane.INFORMATION_MESSAGE;
    
            mensaje = new setearOptionPane();
            mensaje.setMessage(m);
            mensaje.setMessageType(tipo);
            dialogo = mensaje.createDialog(null,t);
            dialogo.setLocationRelativeTo(null);
            dialogo.setVisible(true);    
    }
}