/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javabd_exportar;
import javax.swing.JOptionPane;

/**
 *
 * @author Laura Noussan Lettry <laura@lnoussanl.org>
 * @Name setearOptionPan
 * @Created on 16/05/2015
 */

@SuppressWarnings("serial")
public class setearOptionPane extends JOptionPane{

  public setearOptionPane() {
  }

    @Override
  public int getMaxCharactersPerLineCount() {
    return 100;
  }
} 
    

