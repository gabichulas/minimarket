package javabd_mapeo.core;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Laura Noussan Lettry <laura@lnoussanl.org>
 * @Name UsarConexion
 * @Created ON 23/02/2013
 * @Created ON 14/05/2014 (actualizado)
 * pertenece a javabd_mapeo_core version 2 - 2014
 * @Created ON 29/08/2020 (actualizado) para mejorar el código
 */

public class UsarConexion {
    Connection miConexion;
    Statement sentencia=null;
    ResultSet resultado;
    
    public UsarConexion(Connection c){
        this.miConexion=c;
        
    }
    //en esta versión retorna un entero, si es mayor a cero indica la cantidad
    //de registros afectados, si es igual cero quiere decir que no se pudo
    //llevar a cabo la ABM
    public int ABM(String cadena){
        int operacionesHechas=0;
        try {
         
            sentencia = miConexion.createStatement();
            operacionesHechas = sentencia.executeUpdate(cadena);
            if(miConexion.getAutoCommit()!=true)
                miConexion.commit();
            
        } catch (SQLException ex) {
                    String mensajeExcepcion="Error al realizar la ABM: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return operacionesHechas;
       
    }
    
    public void Consultar(String cadena){
        try {
            sentencia = miConexion.createStatement();
            sentencia.executeQuery(cadena);
            resultado = sentencia.getResultSet();
        
        } catch (SQLException ex) {
                    String mensajeExcepcion="Error al realizar la Consulta: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;            
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//fin Consultar
    public int getCantidadRegistros(){
        
        int cantFilas=0;
        try {
            resultado.last();
            cantFilas = resultado.getRow();
            resultado.first();
        } catch (SQLException ex) {
                    String mensajeExcepcion="Error al devolver la cantidad de columnas: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;               
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cantFilas;
  
    }
    public int getCantidadColumnasTabla(){
        int cantCols=0;
        try {
            cantCols=resultado.getMetaData().getColumnCount();
        } catch (SQLException ex) {
                    String mensajeExcepcion="Error al devolver la cantidad de columnas: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;              
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cantCols;
    }
    public String getNombreColumnaTabla(int columna){
        String nombre="";
        try {        
        nombre=resultado.getMetaData().getColumnName(columna);
        
    } catch (SQLException ex) {
            String mensajeExcepcion="Error al devolver el nombre de la columna: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;          
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }
        return nombre;
    }
    public String getTipoDatosColumnaTabla(int columna){
        String nombre="";
        try {     
        nombre=resultado.getMetaData().getColumnTypeName(columna);
     } catch (SQLException ex) {
            String mensajeExcepcion="Error al devolver el nombre de la columna: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;          
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }
        return nombre;
    }
    public int getTamanioColumnaTabla(int columna){
        int cantidad=0;
        try {           
        cantidad=resultado.getMetaData().getColumnDisplaySize(columna);
    } catch (SQLException ex) {
            String mensajeExcepcion="Error al devolver el tamaño de la columna: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;          
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }        
        return cantidad;
    }

    public String[] getObtenerNombresColumnas(){
       String nomCols[];
       int i=0;
           int cantCols = this.getCantidadColumnasTabla();
           nomCols=new String[cantCols];
           for(i=0;i<cantCols;i++){
               nomCols[i]=new StringBuilder(this.getTamanioColumnaTabla(i+1)).toString();
               nomCols[i]=this.getNombreColumnaTabla(i+1)+"  |  ";
           }
          
           return nomCols;
     }//fin getObtenerNombresColumnas
    
    public String getObtenerDatos(){
        String datos="";        
        try {
        int i;  
           int cantCols = this.getCantidadColumnasTabla();
            
           while (resultado.next()){//el recodrset es una fila con 'n' columnas
               String fila="";
                for(i=0;i<cantCols;i++){
                    //el contenido o valor de cada atributo
                    fila+=resultado.getString(i+1)+" | ";
                }//los datos de un registro
                datos+="\n"+fila;
               }//fin while    
           
       } catch (SQLException ex) {
            String mensajeExcepcion="Error al leer los datos del RecordSet: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;           
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }
      return datos;
    }//fin getObtenerDatos
    //método para obtener un arreglo de los datos, o sea, un registro
    //para modificar o eliminar
    public String[] getObtenerDatosClave(){
        int cantCols = this.getCantidadColumnasTabla();
        String datos[]=new String[cantCols];        
        try {
        int i;  
           while (resultado.next()){//el recodrset es una fila con 'n' columnas
                for(i=0;i<cantCols;i++){
                datos[i]= resultado.getString(i+1);
                }//fin for
               }//fin while    
           
       } catch (SQLException ex) {
            String mensajeExcepcion="Error al leer los datos del RecordSet: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;           
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }
      return datos;
    }//fin getObtenerDatos  
    
    //con JTable
    public String[] getObtenerNombresColumnasJTable(){
       String nomCols[];
       int i=0;
           int cantCols = this.getCantidadColumnasTabla();
           nomCols=new String[cantCols];
           for(i=0;i<cantCols;i++){
               nomCols[i]=new StringBuilder(this.getTamanioColumnaTabla(i+1)).toString();
               nomCols[i]=this.getNombreColumnaTabla(i+1);
           }
          
           return nomCols;
     }//fin getObtenerNombresColumnasJTable
    
    //con JTable
    public DefaultTableModel getObtenerDatosJTable(){
         
     DefaultTableModel modelo=null;
      try{
        
        String tupla[]= new String [this.getCantidadColumnasTabla()];
        String titulos[]=this.getObtenerNombresColumnasJTable();
        //crear el modelo y la cabecera de la tabla
        modelo=new DefaultTableModel(null,titulos);
         while (resultado.next()){
             int j=1;
           for(int i=0;i<tupla.length;i++){ 
            tupla[i]=resultado.getString(this.getNombreColumnaTabla(j++));
            }
            modelo.addRow(tupla);
           }
       } 
      catch (SQLException ex) {
            String mensajeExcepcion="Error al leer los datos del RecordSet: \n"+
                    ex.getMessage()+
                    "\nLocalización: "+
                    ex.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción!",1 ) ;           
            Logger.getLogger(UsarConexion.class.getName()).log(Level.SEVERE, null, ex);
       }
      return modelo;
    }//fin getObtenerDatos2
}