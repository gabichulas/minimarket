package javabd_mapeo.core;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Laura Noussan Lettry <laura@lnoussanl.org>
 * @Name Conectar
 * @Created ON 23/02/2013
 * @Created ON 14/05/2014 (actualizado)
 * pertenece a javabd_mapeo_core version 2 - 2014
 * @Created ON 29/08/2020 (actualizado) para mejorar el código
 */

public class Conectar {
    //atributos con los que vamos a crear un objeto Connection
    private static Connection conn=null;//variable que maneja la conexion

    //constructor
    public Conectar(String driver, String cadena, String usuario, String clave){
        //primero setear el Driver
        //pero tenemos que usar excepciones, no hay otra
        try{
        String controlador = driver;
        Class.forName(controlador).newInstance();
        //si ya tenemos el controlador instanciado podemos crear la conexión
            try{
                conn=DriverManager.getConnection(cadena,usuario,clave);
                JOptionPane.showMessageDialog(null,"Conectado!!","Información",1 ) ;
                
            }//fin try por conexion ya establecido el driver
            catch (SQLException  e){
                String mensajeExcepcion="Error al realizar la Conexión: \n"+
                        e.getMessage()+
                        "\nLocalización: "+
                        e.getLocalizedMessage();
                JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;   
            }
            catch (HeadlessException e){
                String mensajeExcepcion="Error al realizar la Conexión: \n"+
                        e.getMessage()+
                        "\nLocalización: "+
                        e.getLocalizedMessage();
                JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;   
            }            
        }//fin try por Driver       
        catch(ClassNotFoundException  e){
            String mensajeExcepcion="Error al cargar el controlador: \n"+
                    e.getMessage()+
                    "\nLocalización: "+
                    e.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;
        }
        catch(InstantiationException  e){
            String mensajeExcepcion="Error al cargar el controlador: \n"+
                    e.getMessage()+
                    "\nLocalización: "+
                    e.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;
        }    
        catch(IllegalAccessException e){
            String mensajeExcepcion="Error al cargar el controlador: \n"+
                    e.getMessage()+
                    "\nLocalización: "+
                    e.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;
        }        
    }//fin constructor
    public void Desconectar(){
        try {
            if(conn != null){
               conn.close();
               conn = null;  //cambiar el valor del componente static
               String mensaje="Desconectado!!";
               JOptionPane.showMessageDialog(null,mensaje,"Información",1 ) ;
            }//fin if
        }//fin try
        catch (SQLException e){
            String mensajeExcepcion="Error al Desconectar: \n"+
                    e.getMessage()+
                    "\nLocalización: "+
                    e.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;

         }//fin catch
        catch (HeadlessException e){
            String mensajeExcepcion="Error al Desconectar: \n"+
                    e.getMessage()+
                    "\nLocalización: "+
                    e.getLocalizedMessage();
            JOptionPane.showMessageDialog(null,mensajeExcepcion,"Excepción !!",1 ) ;

         }//fin catch        
    }//fin método Desconectar()
    public static Connection getConexion(){
            return Conectar.conn;
      }
}